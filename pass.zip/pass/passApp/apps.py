from django.apps import AppConfig


class PassappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'passApp'
